from django.apps import AppConfig


class TumblrappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TumblrApp'
